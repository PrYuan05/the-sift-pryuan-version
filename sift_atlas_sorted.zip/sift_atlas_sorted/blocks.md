| 序號 | 預擬命名 ID | 中文方塊名稱 | 分類歸屬 | 輸出檔名 | 來源坐標 | 備註 |
| :-- | :-- | :-- | :-- | :-- | :-- | :-- |
| 1 | sift:amber_capped_stone_01 | 琥珀覆蓋灰石岩 01 | The Sift 維度 | sift_amber_capped_stone_01_side.png<br>sift_amber_capped_stone_01_top.png<br>sift_amber_capped_stone_01_bottom.png | side:r26_c39<br>top:r26_c20<br>bottom:r26_c37 | ⚠ 側面頂部有覆蓋層；頂/底面為依色彩最近鄰推測(距離 11/1)，請確認 |
| 2 | sift:amber_capped_stone_02 | 琥珀覆蓋灰石岩 02 | The Sift 維度 | sift_amber_capped_stone_02_side.png<br>sift_amber_capped_stone_02_top.png<br>sift_amber_capped_stone_02_bottom.png | side:r26_c50<br>top:r26_c49<br>bottom:r26_c44 | ⚠ 側面頂部有覆蓋層；頂/底面為依色彩最近鄰推測(距離 5/0)，請確認 |
| 3 | sift:amber_capped_stone_03 | 琥珀覆蓋灰石岩 03 | The Sift 維度 | sift_amber_capped_stone_03_side.png<br>sift_amber_capped_stone_03_top.png<br>sift_amber_capped_stone_03_bottom.png | side:r27_c09<br>top:r27_c05<br>bottom:r24_c29 | ⚠ 側面頂部有覆蓋層；頂/底面為依色彩最近鄰推測(距離 5/8)，請確認 |
| 4 | sift:amber_strata_01 | 琥珀地層岩 01 | The Sift 維度 | sift_amber_strata_01.png | all:r23_c47 | 依色系自動命名，紋理需人工複核 |
| 5 | sift:amber_strata_02 | 琥珀地層岩 02 | The Sift 維度 | sift_amber_strata_02.png | all:r23_c48 | 依色系自動命名，紋理需人工複核 |
| 6 | sift:amber_strata_03 | 琥珀地層岩 03 | The Sift 維度 | sift_amber_strata_03.png | all:r23_c61 | 依色系自動命名，紋理需人工複核 |
| 7 | sift:amber_strata_04 | 琥珀地層岩 04 | The Sift 維度 | sift_amber_strata_04.png | all:r23_c62 | 依色系自動命名，紋理需人工複核 |
| 8 | sift:amber_strata_05 | 琥珀地層岩 05 | The Sift 維度 | sift_amber_strata_05.png | all:r26_c16 | 依色系自動命名，紋理需人工複核 |
| 9 | sift:amber_strata_06 | 琥珀地層岩 06 | The Sift 維度 | sift_amber_strata_06.png | all:r26_c21 | 依色系自動命名，紋理需人工複核 |
| 10 | sift:amber_strata_07 | 琥珀地層岩 07 | The Sift 維度 | sift_amber_strata_07.png | all:r26_c22 | 依色系自動命名，紋理需人工複核 |
| 11 | sift:amber_strata_08 | 琥珀地層岩 08 | The Sift 維度 | sift_amber_strata_08.png | all:r26_c48 | 依色系自動命名，紋理需人工複核 |
| 12 | sift:argent_ore | 銀白礦 | The Sift 維度 | sift_argent_ore.png | all:r22_c36 |  |
| 13 | sift:ash_capped_crimson_01 | 灰白覆蓋赤紅岩 01 | The Sift 維度 | sift_ash_capped_crimson_01_side.png<br>sift_ash_capped_crimson_01_top.png<br>sift_ash_capped_crimson_01_bottom.png | side:r24_c40<br>top:r24_c52<br>bottom:r24_c44 | ⚠ 側面頂部有覆蓋層；頂/底面為依色彩最近鄰推測(距離 20/3)，請確認 |
| 14 | sift:ash_capped_dark_slate_01 | 灰白覆蓋深板岩 01 | The Sift 維度 | sift_ash_capped_dark_slate_01_side.png<br>sift_ash_capped_dark_slate_01_top.png<br>sift_ash_capped_dark_slate_01_bottom.png | side:r27_c49<br>top:r24_c30<br>bottom:r27_c48 | ⚠ 側面頂部有覆蓋層；頂/底面為依色彩最近鄰推測(距離 7/1)，請確認 |
| 15 | sift:ash_capped_dark_slate_02 | 灰白覆蓋深板岩 02 | The Sift 維度 | sift_ash_capped_dark_slate_02_side.png<br>sift_ash_capped_dark_slate_02_top.png<br>sift_ash_capped_dark_slate_02_bottom.png | side:r27_c59<br>top:r26_c31<br>bottom:r27_c48 | ⚠ 側面頂部有覆蓋層；頂/底面為依色彩最近鄰推測(距離 11/1)，請確認 |
| 16 | sift:ash_capped_violet_01 | 灰白覆蓋紫晶岩 01 | The Sift 維度 | sift_ash_capped_violet_01_side.png<br>sift_ash_capped_violet_01_top.png<br>sift_ash_capped_violet_01_bottom.png | side:r27_c53<br>top:r24_c30<br>bottom:r25_c17 | ⚠ 側面頂部有覆蓋層；頂/底面為依色彩最近鄰推測(距離 7/2)，請確認 |
| 17 | sift:ash_marble_01 | 灰白大理石 01 | The Sift 維度 | sift_ash_marble_01.png | all:r27_c44 |  |
| 18 | sift:ash_marble_02 | 灰白大理石 02 | The Sift 維度 | sift_ash_marble_02.png | all:r27_c45 |  |
| 19 | sift:ash_marble_03 | 灰白大理石 03 | The Sift 維度 | sift_ash_marble_03.png | all:r27_c46 |  |
| 20 | sift:ash_marble_04 | 灰白大理石 04 | The Sift 維度 | sift_ash_marble_04.png | all:r27_c47 |  |
| 21 | sift:ash_stone_01 | 灰白岩 01 | The Sift 維度 | sift_ash_stone_01.png | all:r24_c42 | 依色系自動命名，紋理需人工複核 |
| 22 | sift:ash_stone_02 | 灰白岩 02 | The Sift 維度 | sift_ash_stone_02.png | all:r24_c50 | 依色系自動命名，紋理需人工複核 |
| 23 | sift:ash_stone_03 | 灰白岩 03 | The Sift 維度 | sift_ash_stone_03.png | all:r26_c15 | 依色系自動命名，紋理需人工複核 |
| 24 | sift:ash_stone_04 | 灰白岩 04 | The Sift 維度 | sift_ash_stone_04.png | all:r26_c17 | 依色系自動命名，紋理需人工複核 |
| 25 | sift:ash_stone_05 | 灰白岩 05 | The Sift 維度 | sift_ash_stone_05.png | all:r26_c18 | 依色系自動命名，紋理需人工複核 |
| 26 | sift:aurum_lapis_ore | 金青金礦 | The Sift 維度 | sift_aurum_lapis_ore.png | all:r26_c52 |  |
| 27 | sift:aurum_ore_a | 金岩礦 A | The Sift 維度 | sift_aurum_ore_a.png | all:r22_c34 |  |
| 28 | sift:aurum_ore_b | 金岩礦 B | The Sift 維度 | sift_aurum_ore_b.png | all:r22_c35 |  |
| 29 | sift:circle_slate | 圓紋板岩 | The Sift 維度 | sift_circle_slate.png | all:r22_c06 |  |
| 30 | sift:crimson_capped_void_01 | 赤紅覆蓋虛黑岩 01 | The Sift 維度 | sift_crimson_capped_void_01_side.png<br>sift_crimson_capped_void_01_top.png<br>sift_crimson_capped_void_01_bottom.png | side:r24_c54<br>top:r23_c56<br>bottom:r24_c57 | ⚠ 側面頂部有覆蓋層；頂/底面為依色彩最近鄰推測(距離 4/2)，請確認 |
| 31 | sift:crimson_strata_01 | 赤紅地層岩 01 | The Sift 維度 | sift_crimson_strata_01.png | all:r22_c09 | 依色系自動命名，紋理需人工複核 |
| 32 | sift:crimson_strata_02 | 赤紅地層岩 02 | The Sift 維度 | sift_crimson_strata_02.png | all:r22_c43 | 依色系自動命名，紋理需人工複核 |
| 33 | sift:crimson_strata_03 | 赤紅地層岩 03 | The Sift 維度 | sift_crimson_strata_03.png | all:r23_c33 | 依色系自動命名，紋理需人工複核 |
| 34 | sift:crimson_strata_04 | 赤紅地層岩 04 | The Sift 維度 | sift_crimson_strata_04.png | all:r23_c37 | 依色系自動命名，紋理需人工複核 |
| 35 | sift:crimson_strata_05 | 赤紅地層岩 05 | The Sift 維度 | sift_crimson_strata_05.png | all:r23_c43 | 依色系自動命名，紋理需人工複核 |
| 36 | sift:crimson_strata_06 | 赤紅地層岩 06 | The Sift 維度 | sift_crimson_strata_06.png | all:r23_c44 | 依色系自動命名，紋理需人工複核 |
| 37 | sift:crimson_strata_07 | 赤紅地層岩 07 | The Sift 維度 | sift_crimson_strata_07.png | all:r23_c46 | 依色系自動命名，紋理需人工複核 |
| 38 | sift:crimson_strata_08 | 赤紅地層岩 08 | The Sift 維度 | sift_crimson_strata_08.png | all:r23_c52 | 依色系自動命名，紋理需人工複核 |
| 39 | sift:crimson_strata_09 | 赤紅地層岩 09 | The Sift 維度 | sift_crimson_strata_09.png | all:r23_c55 | 依色系自動命名，紋理需人工複核 |
| 40 | sift:crimson_strata_10 | 赤紅地層岩 10 | The Sift 維度 | sift_crimson_strata_10.png | all:r23_c57 | 依色系自動命名，紋理需人工複核 |
| 41 | sift:crimson_strata_11 | 赤紅地層岩 11 | The Sift 維度 | sift_crimson_strata_11.png | all:r23_c58 | 依色系自動命名，紋理需人工複核 |
| 42 | sift:crimson_strata_12 | 赤紅地層岩 12 | The Sift 維度 | sift_crimson_strata_12.png | all:r23_c60 | 依色系自動命名，紋理需人工複核 |
| 43 | sift:crimson_strata_13 | 赤紅地層岩 13 | The Sift 維度 | sift_crimson_strata_13.png | all:r24_c00 | 依色系自動命名，紋理需人工複核 |
| 44 | sift:crimson_strata_14 | 赤紅地層岩 14 | The Sift 維度 | sift_crimson_strata_14.png | all:r24_c02 | 依色系自動命名，紋理需人工複核 |
| 45 | sift:crimson_strata_15 | 赤紅地層岩 15 | The Sift 維度 | sift_crimson_strata_15.png | all:r24_c03 | 依色系自動命名，紋理需人工複核 |
| 46 | sift:crimson_strata_16 | 赤紅地層岩 16 | The Sift 維度 | sift_crimson_strata_16.png | all:r24_c04 | 依色系自動命名，紋理需人工複核 |
| 47 | sift:crimson_strata_17 | 赤紅地層岩 17 | The Sift 維度 | sift_crimson_strata_17.png | all:r24_c05 | 依色系自動命名，紋理需人工複核 |
| 48 | sift:crimson_strata_18 | 赤紅地層岩 18 | The Sift 維度 | sift_crimson_strata_18.png | all:r24_c08 | 依色系自動命名，紋理需人工複核 |
| 49 | sift:crimson_strata_19 | 赤紅地層岩 19 | The Sift 維度 | sift_crimson_strata_19.png | all:r24_c36 | 依色系自動命名，紋理需人工複核 |
| 50 | sift:crimson_strata_20 | 赤紅地層岩 20 | The Sift 維度 | sift_crimson_strata_20.png | all:r24_c37 | 依色系自動命名，紋理需人工複核 |
| 51 | sift:crimson_strata_21 | 赤紅地層岩 21 | The Sift 維度 | sift_crimson_strata_21.png | all:r24_c47 | 依色系自動命名，紋理需人工複核 |
| 52 | sift:crimson_strata_22 | 赤紅地層岩 22 | The Sift 維度 | sift_crimson_strata_22.png | all:r24_c56 | 依色系自動命名，紋理需人工複核 |
| 53 | sift:crimson_strata_23 | 赤紅地層岩 23 | The Sift 維度 | sift_crimson_strata_23.png | all:r25_c00 | 依色系自動命名，紋理需人工複核 |
| 54 | sift:crimson_strata_24 | 赤紅地層岩 24 | The Sift 維度 | sift_crimson_strata_24.png | all:r25_c01 | 依色系自動命名，紋理需人工複核 |
| 55 | sift:crimson_strata_25 | 赤紅地層岩 25 | The Sift 維度 | sift_crimson_strata_25.png | all:r25_c05 | 依色系自動命名，紋理需人工複核 |
| 56 | sift:crimson_strata_26 | 赤紅地層岩 26 | The Sift 維度 | sift_crimson_strata_26.png | all:r25_c06 | 依色系自動命名，紋理需人工複核 |
| 57 | sift:crimson_strata_27 | 赤紅地層岩 27 | The Sift 維度 | sift_crimson_strata_27.png | all:r25_c08 | 依色系自動命名，紋理需人工複核 |
| 58 | sift:crimson_strata_28 | 赤紅地層岩 28 | The Sift 維度 | sift_crimson_strata_28.png | all:r25_c09 | 依色系自動命名，紋理需人工複核 |
| 59 | sift:crimson_strata_29 | 赤紅地層岩 29 | The Sift 維度 | sift_crimson_strata_29.png | all:r26_c19 | 依色系自動命名，紋理需人工複核 |
| 60 | sift:crimson_strata_30 | 赤紅地層岩 30 | The Sift 維度 | sift_crimson_strata_30.png | all:r26_c42 | 依色系自動命名，紋理需人工複核 |
| 61 | sift:crimson_strata_31 | 赤紅地層岩 31 | The Sift 維度 | sift_crimson_strata_31.png | all:r26_c47 | 依色系自動命名，紋理需人工複核 |
| 62 | sift:crimson_strata_32 | 赤紅地層岩 32 | The Sift 維度 | sift_crimson_strata_32.png | all:r27_c31 | 依色系自動命名，紋理需人工複核 |
| 63 | sift:crimson_strata_33 | 赤紅地層岩 33 | The Sift 維度 | sift_crimson_strata_33.png | all:r27_c32 | 依色系自動命名，紋理需人工複核 |
| 64 | sift:crimson_strata_34 | 赤紅地層岩 34 | The Sift 維度 | sift_crimson_strata_34.png | all:r27_c33 | 依色系自動命名，紋理需人工複核 |
| 65 | sift:crimson_strata_35 | 赤紅地層岩 35 | The Sift 維度 | sift_crimson_strata_35.png | all:r27_c61 | 依色系自動命名，紋理需人工複核 |
| 66 | sift:crimson_strata_36 | 赤紅地層岩 36 | The Sift 維度 | sift_crimson_strata_36.png | all:r27_c62 | 依色系自動命名，紋理需人工複核 |
| 67 | sift:dark_slate_01 | 深色板岩 01 | The Sift 維度 | sift_dark_slate_01.png | all:r22_c10 | 依色系自動命名，紋理需人工複核 |
| 68 | sift:dark_slate_02 | 深色板岩 02 | The Sift 維度 | sift_dark_slate_02.png | all:r23_c19 | 依色系自動命名，紋理需人工複核 |
| 69 | sift:dark_slate_03 | 深色板岩 03 | The Sift 維度 | sift_dark_slate_03.png | all:r23_c31 | 依色系自動命名，紋理需人工複核 |
| 70 | sift:dark_slate_04 | 深色板岩 04 | The Sift 維度 | sift_dark_slate_04.png | all:r23_c32 | 依色系自動命名，紋理需人工複核 |
| 71 | sift:dark_slate_05 | 深色板岩 05 | The Sift 維度 | sift_dark_slate_05.png | all:r24_c06 | 依色系自動命名，紋理需人工複核 |
| 72 | sift:dark_slate_06 | 深色板岩 06 | The Sift 維度 | sift_dark_slate_06.png | all:r24_c11 | 依色系自動命名，紋理需人工複核 |
| 73 | sift:dark_slate_07 | 深色板岩 07 | The Sift 維度 | sift_dark_slate_07.png | all:r24_c14 | 依色系自動命名，紋理需人工複核 |
| 74 | sift:dark_slate_08 | 深色板岩 08 | The Sift 維度 | sift_dark_slate_08.png | all:r24_c17 | 依色系自動命名，紋理需人工複核 |
| 75 | sift:dark_slate_09 | 深色板岩 09 | The Sift 維度 | sift_dark_slate_09.png | all:r24_c18 | 依色系自動命名，紋理需人工複核 |
| 76 | sift:dark_slate_10 | 深色板岩 10 | The Sift 維度 | sift_dark_slate_10.png | all:r24_c20 | 依色系自動命名，紋理需人工複核 |
| 77 | sift:dark_slate_11 | 深色板岩 11 | The Sift 維度 | sift_dark_slate_11.png | all:r24_c21 | 依色系自動命名，紋理需人工複核 |
| 78 | sift:dark_slate_12 | 深色板岩 12 | The Sift 維度 | sift_dark_slate_12.png | all:r24_c22 | 依色系自動命名，紋理需人工複核 |
| 79 | sift:dark_slate_13 | 深色板岩 13 | The Sift 維度 | sift_dark_slate_13.png | all:r24_c25 | 依色系自動命名，紋理需人工複核 |
| 80 | sift:dark_slate_14 | 深色板岩 14 | The Sift 維度 | sift_dark_slate_14.png | all:r24_c26 | 依色系自動命名，紋理需人工複核 |
| 81 | sift:dark_slate_15 | 深色板岩 15 | The Sift 維度 | sift_dark_slate_15.png | all:r24_c33 | 依色系自動命名，紋理需人工複核 |
| 82 | sift:dark_slate_16 | 深色板岩 16 | The Sift 維度 | sift_dark_slate_16.png | all:r25_c22 | 依色系自動命名，紋理需人工複核 |
| 83 | sift:dark_slate_17 | 深色板岩 17 | The Sift 維度 | sift_dark_slate_17.png | all:r25_c23 | 依色系自動命名，紋理需人工複核 |
| 84 | sift:dark_slate_18 | 深色板岩 18 | The Sift 維度 | sift_dark_slate_18.png | all:r25_c26 | 依色系自動命名，紋理需人工複核 |
| 85 | sift:dark_slate_19 | 深色板岩 19 | The Sift 維度 | sift_dark_slate_19.png | all:r25_c30 | 依色系自動命名，紋理需人工複核 |
| 86 | sift:dark_slate_20 | 深色板岩 20 | The Sift 維度 | sift_dark_slate_20.png | all:r25_c32 | 依色系自動命名，紋理需人工複核 |
| 87 | sift:dark_slate_21 | 深色板岩 21 | The Sift 維度 | sift_dark_slate_21.png | all:r25_c35 | 依色系自動命名，紋理需人工複核 |
| 88 | sift:dark_slate_22 | 深色板岩 22 | The Sift 維度 | sift_dark_slate_22.png | all:r25_c38 | 依色系自動命名，紋理需人工複核 |
| 89 | sift:dark_slate_23 | 深色板岩 23 | The Sift 維度 | sift_dark_slate_23.png | all:r25_c41 | 依色系自動命名，紋理需人工複核 |
| 90 | sift:dark_slate_24 | 深色板岩 24 | The Sift 維度 | sift_dark_slate_24.png | all:r25_c55 | 依色系自動命名，紋理需人工複核 |
| 91 | sift:dark_slate_25 | 深色板岩 25 | The Sift 維度 | sift_dark_slate_25.png | all:r25_c62 | 依色系自動命名，紋理需人工複核 |
| 92 | sift:dark_slate_26 | 深色板岩 26 | The Sift 維度 | sift_dark_slate_26.png | all:r26_c00 | 依色系自動命名，紋理需人工複核 |
| 93 | sift:dark_slate_27 | 深色板岩 27 | The Sift 維度 | sift_dark_slate_27.png | all:r26_c02 | 依色系自動命名，紋理需人工複核 |
| 94 | sift:dark_slate_28 | 深色板岩 28 | The Sift 維度 | sift_dark_slate_28.png | all:r26_c05 | 依色系自動命名，紋理需人工複核 |
| 95 | sift:dark_slate_29 | 深色板岩 29 | The Sift 維度 | sift_dark_slate_29.png | all:r26_c60 | 依色系自動命名，紋理需人工複核 |
| 96 | sift:dark_slate_30 | 深色板岩 30 | The Sift 維度 | sift_dark_slate_30.png | all:r26_c61 | 依色系自動命名，紋理需人工複核 |
| 97 | sift:dark_slate_31 | 深色板岩 31 | The Sift 維度 | sift_dark_slate_31.png | all:r28_c00 | 依色系自動命名，紋理需人工複核 |
| 98 | sift:dark_slate_32 | 深色板岩 32 | The Sift 維度 | sift_dark_slate_32.png | all:r28_c01 | 依色系自動命名，紋理需人工複核 |
| 99 | sift:dark_slate_33 | 深色板岩 33 | The Sift 維度 | sift_dark_slate_33.png | all:r28_c02 | 依色系自動命名，紋理需人工複核 |
| 100 | sift:dark_slate_34 | 深色板岩 34 | The Sift 維度 | sift_dark_slate_34.png | all:r28_c03 | 依色系自動命名，紋理需人工複核 |
| 101 | sift:dark_slate_35 | 深色板岩 35 | The Sift 維度 | sift_dark_slate_35.png | all:r28_c04 | 依色系自動命名，紋理需人工複核 |
| 102 | sift:dark_slate_36 | 深色板岩 36 | The Sift 維度 | sift_dark_slate_36.png | all:r28_c05 | 依色系自動命名，紋理需人工複核 |
| 103 | sift:dark_slate_37 | 深色板岩 37 | The Sift 維度 | sift_dark_slate_37.png | all:r28_c06 | 依色系自動命名，紋理需人工複核 |
| 104 | sift:dark_slate_capped_ash_01 | 深板岩覆蓋灰白岩 01 | The Sift 維度 | sift_dark_slate_capped_ash_01_side.png<br>sift_dark_slate_capped_ash_01_top.png<br>sift_dark_slate_capped_ash_01_bottom.png | side:r27_c60<br>top:r27_c48<br>bottom:r26_c31 | ⚠ 側面頂部有覆蓋層；頂/底面為依色彩最近鄰推測(距離 2/10)，請確認 |
| 105 | sift:dark_slate_capped_rose_01 | 深板岩覆蓋玫瑰岩 01 | The Sift 維度 | sift_dark_slate_capped_rose_01_side.png<br>sift_dark_slate_capped_rose_01_top.png<br>sift_dark_slate_capped_rose_01_bottom.png | side:r25_c53<br>top:r25_c24<br>bottom:r25_c13 | ⚠ 側面頂部有覆蓋層；頂/底面為依色彩最近鄰推測(距離 1/6)，請確認 |
| 106 | sift:diamond_slate_a | 菱紋板岩 A | The Sift 維度 | sift_diamond_slate_a.png | all:r22_c22 |  |
| 107 | sift:diamond_slate_b | 菱紋板岩 B | The Sift 維度 | sift_diamond_slate_b.png | all:r22_c23 |  |
| 108 | sift:emerald_marble_01 | 翡翠斑大理石 01 | The Sift 維度 | sift_emerald_marble_01.png | all:r26_c23 |  |
| 109 | sift:emerald_marble_02 | 翡翠斑大理石 02 | The Sift 維度 | sift_emerald_marble_02.png | all:r26_c24 |  |
| 110 | sift:emerald_sandstone_01 | 翡翠斑砂岩 01 | The Sift 維度 | sift_emerald_sandstone_01.png | all:r26_c25 |  |
| 111 | sift:emerald_sandstone_02 | 翡翠斑砂岩 02 | The Sift 維度 | sift_emerald_sandstone_02.png | all:r26_c26 |  |
| 112 | sift:framed_slate | 方框板岩 | The Sift 維度 | sift_framed_slate.png | all:r22_c00 |  |
| 113 | sift:gilded_rune_slate | 鎏金符文板岩 | The Sift 維度 | sift_gilded_rune_slate.png | all:r22_c20 |  |
| 114 | sift:glyph_block_01 | 符文塊 01 | The Sift 維度 | sift_glyph_block_01.png | all:r25_c58 | 暗底+鮭粉迷宮/符文紋 |
| 115 | sift:glyph_block_02 | 符文塊 02 | The Sift 維度 | sift_glyph_block_02.png | all:r25_c59 | 暗底+鮭粉迷宮/符文紋 |
| 116 | sift:glyph_block_03 | 符文塊 03 | The Sift 維度 | sift_glyph_block_03.png | all:r25_c60 | 暗底+鮭粉迷宮/符文紋 |
| 117 | sift:glyph_block_04 | 符文塊 04 | The Sift 維度 | sift_glyph_block_04.png | all:r25_c61 | 暗底+鮭粉迷宮/符文紋 |
| 118 | sift:glyph_veined_block_01 | 紫脈符文塊 01 | The Sift 維度 | sift_glyph_veined_block_01.png | all:r26_c07 |  |
| 119 | sift:glyph_veined_block_02 | 紫脈符文塊 02 | The Sift 維度 | sift_glyph_veined_block_02.png | all:r26_c08 |  |
| 120 | sift:glyph_veined_block_03 | 紫脈符文塊 03 | The Sift 維度 | sift_glyph_veined_block_03.png | all:r26_c09 |  |
| 121 | sift:gray_strata_01 | 灰色地層岩 01 | The Sift 維度 | sift_gray_strata_01.png | all:r23_c38 | 依色系自動命名，紋理需人工複核 |
| 122 | sift:gray_strata_02 | 灰色地層岩 02 | The Sift 維度 | sift_gray_strata_02.png | all:r24_c12 | 依色系自動命名，紋理需人工複核 |
| 123 | sift:gray_strata_03 | 灰色地層岩 03 | The Sift 維度 | sift_gray_strata_03.png | all:r24_c27 | 依色系自動命名，紋理需人工複核 |
| 124 | sift:gray_strata_04 | 灰色地層岩 04 | The Sift 維度 | sift_gray_strata_04.png | all:r24_c31 | 依色系自動命名，紋理需人工複核 |
| 125 | sift:gray_strata_05 | 灰色地層岩 05 | The Sift 維度 | sift_gray_strata_05.png | all:r24_c41 | 依色系自動命名，紋理需人工複核 |
| 126 | sift:gray_strata_06 | 灰色地層岩 06 | The Sift 維度 | sift_gray_strata_06.png | all:r24_c46 | 依色系自動命名，紋理需人工複核 |
| 127 | sift:gray_strata_07 | 灰色地層岩 07 | The Sift 維度 | sift_gray_strata_07.png | all:r24_c48 | 依色系自動命名，紋理需人工複核 |
| 128 | sift:gray_strata_08 | 灰色地層岩 08 | The Sift 維度 | sift_gray_strata_08.png | all:r24_c51 | 依色系自動命名，紋理需人工複核 |
| 129 | sift:gray_strata_09 | 灰色地層岩 09 | The Sift 維度 | sift_gray_strata_09.png | all:r24_c58 | 依色系自動命名，紋理需人工複核 |
| 130 | sift:gray_strata_10 | 灰色地層岩 10 | The Sift 維度 | sift_gray_strata_10.png | all:r25_c10 | 依色系自動命名，紋理需人工複核 |
| 131 | sift:gray_strata_11 | 灰色地層岩 11 | The Sift 維度 | sift_gray_strata_11.png | all:r25_c20 | 依色系自動命名，紋理需人工複核 |
| 132 | sift:gray_strata_12 | 灰色地層岩 12 | The Sift 維度 | sift_gray_strata_12.png | all:r25_c21 | 依色系自動命名，紋理需人工複核 |
| 133 | sift:gray_strata_13 | 灰色地層岩 13 | The Sift 維度 | sift_gray_strata_13.png | all:r26_c32 | 依色系自動命名，紋理需人工複核 |
| 134 | sift:gray_strata_14 | 灰色地層岩 14 | The Sift 維度 | sift_gray_strata_14.png | all:r26_c43 | 依色系自動命名，紋理需人工複核 |
| 135 | sift:gray_strata_15 | 灰色地層岩 15 | The Sift 維度 | sift_gray_strata_15.png | all:r26_c46 | 依色系自動命名，紋理需人工複核 |
| 136 | sift:gray_strata_16 | 灰色地層岩 16 | The Sift 維度 | sift_gray_strata_16.png | all:r28_c07 | 依色系自動命名，紋理需人工複核 |
| 137 | sift:labyrinth_marble | 迷宮紋大理石 | The Sift 維度 | sift_labyrinth_marble.png | all:r23_c10 |  |
| 138 | sift:labyrinth_marble_core | 迷宮紋核心大理石 | The Sift 維度 | sift_labyrinth_marble_core.png | all:r23_c11 |  |
| 139 | sift:ochre_strata_01 | 赭黃地層岩 01 | The Sift 維度 | sift_ochre_strata_01.png | all:r27_c15 | 依色系自動命名，紋理需人工複核 |
| 140 | sift:patina_ore_a | 銅綠礦 A | The Sift 維度 | sift_patina_ore_a.png | all:r22_c03 |  |
| 141 | sift:patina_ore_b | 銅綠礦 B | The Sift 維度 | sift_patina_ore_b.png | all:r22_c04 |  |
| 142 | sift:radiant_rune_slate | 輝金符文板岩 | The Sift 維度 | sift_radiant_rune_slate.png | all:r22_c21 |  |
| 143 | sift:red_sculk_vein_bottom | 赤紅脈塊(底面候選) | The Sift 維度 | sift_red_sculk_vein_bottom.png | all:r28_extra | ⚠ 檔案本身無座標，視為脈塊的另一面 |
| 144 | sift:rose_capped_dark_slate_01 | 玫瑰覆蓋深板岩 01 | The Sift 維度 | sift_rose_capped_dark_slate_01_side.png<br>sift_rose_capped_dark_slate_01_top.png<br>sift_rose_capped_dark_slate_01_bottom.png | side:r25_c52<br>top:r25_c13<br>bottom:r25_c24 | ⚠ 側面頂部有覆蓋層；頂/底面為依色彩最近鄰推測(距離 7/2)，請確認 |
| 145 | sift:rose_capped_stone_01 | 玫瑰覆蓋灰石岩 01 | The Sift 維度 | sift_rose_capped_stone_01_side.png<br>sift_rose_capped_stone_01_top.png<br>sift_rose_capped_stone_01_bottom.png | side:r25_c48<br>top:r25_c19<br>bottom:r25_c25 | ⚠ 側面頂部有覆蓋層；頂/底面為依色彩最近鄰推測(距離 5/2)，請確認 |
| 146 | sift:rose_quartz_ore | 玫瑰石英礦 | The Sift 維度 | sift_rose_quartz_ore.png | all:r26_c51 |  |
| 147 | sift:rose_strata_01 | 玫瑰地層岩 01 | The Sift 維度 | sift_rose_strata_01.png | all:r23_c42 | 依色系自動命名，紋理需人工複核 |
| 148 | sift:rose_strata_02 | 玫瑰地層岩 02 | The Sift 維度 | sift_rose_strata_02.png | all:r24_c34 | 依色系自動命名，紋理需人工複核 |
| 149 | sift:rose_strata_03 | 玫瑰地層岩 03 | The Sift 維度 | sift_rose_strata_03.png | all:r24_c35 | 依色系自動命名，紋理需人工複核 |
| 150 | sift:rose_strata_04 | 玫瑰地層岩 04 | The Sift 維度 | sift_rose_strata_04.png | all:r24_c38 | 依色系自動命名，紋理需人工複核 |
| 151 | sift:rose_strata_05 | 玫瑰地層岩 05 | The Sift 維度 | sift_rose_strata_05.png | all:r24_c45 | 依色系自動命名，紋理需人工複核 |
| 152 | sift:rose_strata_06 | 玫瑰地層岩 06 | The Sift 維度 | sift_rose_strata_06.png | all:r25_c02 | 依色系自動命名，紋理需人工複核 |
| 153 | sift:rose_strata_07 | 玫瑰地層岩 07 | The Sift 維度 | sift_rose_strata_07.png | all:r25_c04 | 依色系自動命名，紋理需人工複核 |
| 154 | sift:rose_strata_08 | 玫瑰地層岩 08 | The Sift 維度 | sift_rose_strata_08.png | all:r25_c12 | 依色系自動命名，紋理需人工複核 |
| 155 | sift:rose_strata_09 | 玫瑰地層岩 09 | The Sift 維度 | sift_rose_strata_09.png | all:r26_c03 | 依色系自動命名，紋理需人工複核 |
| 156 | sift:sky_block_01 | 天空塊 01 | The Sift 維度 | sift_sky_block_01.png | all:r27_c19 | 天藍色+雲紋，非原版色系 |
| 157 | sift:sky_block_02 | 天空塊 02 | The Sift 維度 | sift_sky_block_02.png | all:r27_c20 | 天藍色+雲紋，非原版色系 |
| 158 | sift:sky_block_03 | 天空塊 03 | The Sift 維度 | sift_sky_block_03.png | all:r27_c21 | 天藍色+雲紋，非原版色系 |
| 159 | sift:spiral_carved_stone | 旋紋雕刻石 | The Sift 維度 | sift_spiral_carved_stone.png | all:r24_c32 |  |
| 160 | sift:stone_capped_amber_01 | 灰石覆蓋琥珀岩 01 | The Sift 維度 | sift_stone_capped_amber_01_side.png<br>sift_stone_capped_amber_01_top.png<br>sift_stone_capped_amber_01_bottom.png | side:r24_c15<br>top:r24_c28<br>bottom:r24_c13 | ⚠ 側面頂部有覆蓋層；頂/底面為依色彩最近鄰推測(距離 1/1)，請確認 |
| 161 | sift:stone_capped_amber_02 | 灰石覆蓋琥珀岩 02 | The Sift 維度 | sift_stone_capped_amber_02_side.png<br>sift_stone_capped_amber_02_top.png<br>sift_stone_capped_amber_02_bottom.png | side:r26_c40<br>top:r26_c37<br>bottom:r26_c38 | ⚠ 側面頂部有覆蓋層；頂/底面為依色彩最近鄰推測(距離 0/1)，請確認 |
| 162 | sift:stone_capped_amber_03 | 灰石覆蓋琥珀岩 03 | The Sift 維度 | sift_stone_capped_amber_03_side.png<br>sift_stone_capped_amber_03_top.png<br>sift_stone_capped_amber_03_bottom.png | side:r27_c14<br>top:r24_c29<br>bottom:r27_c05 | ⚠ 側面頂部有覆蓋層；頂/底面為依色彩最近鄰推測(距離 8/6)，請確認 |
| 163 | sift:stone_capped_rose_01 | 灰石覆蓋玫瑰岩 01 | The Sift 維度 | sift_stone_capped_rose_01_side.png<br>sift_stone_capped_rose_01_top.png<br>sift_stone_capped_rose_01_bottom.png | side:r25_c49<br>top:r25_c25<br>bottom:r25_c19 | ⚠ 側面頂部有覆蓋層；頂/底面為依色彩最近鄰推測(距離 2/4)，請確認 |
| 164 | sift:stone_capped_violet_01 | 灰石覆蓋紫晶岩 01 | The Sift 維度 | sift_stone_capped_violet_01_side.png<br>sift_stone_capped_violet_01_top.png<br>sift_stone_capped_violet_01_bottom.png | side:r24_c39<br>top:r24_c49<br>bottom:r25_c34 | ⚠ 側面頂部有覆蓋層；頂/底面為依色彩最近鄰推測(距離 8/7)，請確認 |
| 165 | sift:teal_block_a | 青碧方塊 A | The Sift 維度 | sift_teal_block_a.png | all:r27_c35 |  |
| 166 | sift:teal_block_b | 青碧方塊 B | The Sift 維度 | sift_teal_block_b.png | all:r27_c36 |  |
| 167 | sift:teal_framed_panel | 青碧框板 | The Sift 維度 | sift_teal_framed_panel_ctm_0.png<br>sift_teal_framed_panel_ctm_1.png<br>sift_teal_framed_panel_ctm_2.png<br>sift_teal_framed_panel_ctm_3.png<br>sift_teal_framed_panel_ctm_4.png<br>sift_teal_framed_panel_ctm_5.png<br>sift_teal_framed_panel_ctm_6.png | ctm_0:r27_c37<br>ctm_1:r27_c38<br>ctm_2:r27_c39<br>ctm_3:r27_c40<br>ctm_4:r27_c41<br>ctm_5:r27_c42<br>ctm_6:r27_c43 | 7 張連接紋理(CTM)式邊框變體，合併為單一方塊 |
| 168 | sift:teal_solid_block | 青碧純色塊 | The Sift 維度 | sift_teal_solid_block.png | all:r27_c57 |  |
| 169 | sift:teal_strata_01 | 青碧地層岩 01 | The Sift 維度 | sift_teal_strata_01.png | all:r23_c34 | 依色系自動命名，紋理需人工複核 |
| 170 | sift:teal_strata_02 | 青碧地層岩 02 | The Sift 維度 | sift_teal_strata_02.png | all:r23_c35 | 依色系自動命名，紋理需人工複核 |
| 171 | sift:teal_strata_03 | 青碧地層岩 03 | The Sift 維度 | sift_teal_strata_03.png | all:r23_c36 | 依色系自動命名，紋理需人工複核 |
| 172 | sift:teal_strata_04 | 青碧地層岩 04 | The Sift 維度 | sift_teal_strata_04.png | all:r23_c39 | 依色系自動命名，紋理需人工複核 |
| 173 | sift:teal_strata_05 | 青碧地層岩 05 | The Sift 維度 | sift_teal_strata_05.png | all:r23_c40 | 依色系自動命名，紋理需人工複核 |
| 174 | sift:teal_strata_06 | 青碧地層岩 06 | The Sift 維度 | sift_teal_strata_06.png | all:r23_c49 | 依色系自動命名，紋理需人工複核 |
| 175 | sift:teal_strata_07 | 青碧地層岩 07 | The Sift 維度 | sift_teal_strata_07.png | all:r23_c51 | 依色系自動命名，紋理需人工複核 |
| 176 | sift:teal_strata_08 | 青碧地層岩 08 | The Sift 維度 | sift_teal_strata_08.png | all:r24_c07 | 依色系自動命名，紋理需人工複核 |
| 177 | sift:teal_strata_09 | 青碧地層岩 09 | The Sift 維度 | sift_teal_strata_09.png | all:r24_c09 | 依色系自動命名，紋理需人工複核 |
| 178 | sift:teal_strata_10 | 青碧地層岩 10 | The Sift 維度 | sift_teal_strata_10.png | all:r24_c10 | 依色系自動命名，紋理需人工複核 |
| 179 | sift:teal_strata_11 | 青碧地層岩 11 | The Sift 維度 | sift_teal_strata_11.png | all:r24_c59 | 依色系自動命名，紋理需人工複核 |
| 180 | sift:teal_strata_12 | 青碧地層岩 12 | The Sift 維度 | sift_teal_strata_12.png | all:r24_c61 | 依色系自動命名，紋理需人工複核 |
| 181 | sift:teal_strata_13 | 青碧地層岩 13 | The Sift 維度 | sift_teal_strata_13.png | all:r26_c27 | 依色系自動命名，紋理需人工複核 |
| 182 | sift:teal_strata_14 | 青碧地層岩 14 | The Sift 維度 | sift_teal_strata_14.png | all:r26_c28 | 依色系自動命名，紋理需人工複核 |
| 183 | sift:teal_strata_15 | 青碧地層岩 15 | The Sift 維度 | sift_teal_strata_15.png | all:r26_c29 | 依色系自動命名，紋理需人工複核 |
| 184 | sift:teal_strata_16 | 青碧地層岩 16 | The Sift 維度 | sift_teal_strata_16.png | all:r26_c30 | 依色系自動命名，紋理需人工複核 |
| 185 | sift:teal_strata_17 | 青碧地層岩 17 | The Sift 維度 | sift_teal_strata_17.png | all:r26_c41 | 依色系自動命名，紋理需人工複核 |
| 186 | sift:teal_water_block | 青碧水紋塊 | The Sift 維度 | sift_teal_water_block.png | all:r27_c34 |  |
| 187 | sift:veined_crimson_stone_01 | 綠脈赤紅岩 01 | The Sift 維度 | sift_veined_crimson_stone_01.png | all:r22_c38 |  |
| 188 | sift:veined_crimson_stone_02 | 綠脈赤紅岩 02 | The Sift 維度 | sift_veined_crimson_stone_02.png | all:r22_c39 |  |
| 189 | sift:veined_teal_stone_01 | 綠脈青碧岩 01 | The Sift 維度 | sift_veined_teal_stone_01.png | all:r22_c40 |  |
| 190 | sift:veined_teal_stone_02 | 綠脈青碧岩 02 | The Sift 維度 | sift_veined_teal_stone_02.png | all:r22_c41 |  |
| 191 | sift:violet_marble_01 | 紫晶大理石 01 | The Sift 維度 | sift_violet_marble_01.png | all:r27_c55 |  |
| 192 | sift:violet_marble_02 | 紫晶大理石 02 | The Sift 維度 | sift_violet_marble_02.png | all:r27_c56 |  |
| 193 | sift:violet_solid_block | 紫晶純色塊 | The Sift 維度 | sift_violet_solid_block.png | all:r27_c58 |  |
| 194 | sift:violet_strata_01 | 紫晶地層岩 01 | The Sift 維度 | sift_violet_strata_01.png | all:r23_c41 | 依色系自動命名，紋理需人工複核 |
| 195 | sift:violet_strata_02 | 紫晶地層岩 02 | The Sift 維度 | sift_violet_strata_02.png | all:r23_c53 | 依色系自動命名，紋理需人工複核 |
| 196 | sift:violet_strata_03 | 紫晶地層岩 03 | The Sift 維度 | sift_violet_strata_03.png | all:r25_c18 | 依色系自動命名，紋理需人工複核 |
| 197 | sift:violet_strata_04 | 紫晶地層岩 04 | The Sift 維度 | sift_violet_strata_04.png | all:r25_c31 | 依色系自動命名，紋理需人工複核 |
| 198 | sift:violet_strata_05 | 紫晶地層岩 05 | The Sift 維度 | sift_violet_strata_05.png | all:r25_c33 | 依色系自動命名，紋理需人工複核 |
| 199 | sift:violet_strata_06 | 紫晶地層岩 06 | The Sift 維度 | sift_violet_strata_06.png | all:r25_c36 | 依色系自動命名，紋理需人工複核 |
| 200 | sift:violet_strata_07 | 紫晶地層岩 07 | The Sift 維度 | sift_violet_strata_07.png | all:r25_c42 | 依色系自動命名，紋理需人工複核 |
| 201 | sift:violet_strata_08 | 紫晶地層岩 08 | The Sift 維度 | sift_violet_strata_08.png | all:r25_c56 | 依色系自動命名，紋理需人工複核 |
| 202 | sift:violet_strata_09 | 紫晶地層岩 09 | The Sift 維度 | sift_violet_strata_09.png | all:r27_c50 | 依色系自動命名，紋理需人工複核 |
| 203 | sift:violet_strata_10 | 紫晶地層岩 10 | The Sift 維度 | sift_violet_strata_10.png | all:r27_c51 | 依色系自動命名，紋理需人工複核 |
| 204 | sift:violet_strata_11 | 紫晶地層岩 11 | The Sift 維度 | sift_violet_strata_11.png | all:r27_c52 | 依色系自動命名，紋理需人工複核 |
| 205 | sift:void_capped_crimson_01 | 虛黑覆蓋赤紅岩 01 | The Sift 維度 | sift_void_capped_crimson_01_side.png<br>sift_void_capped_crimson_01_top.png<br>sift_void_capped_crimson_01_bottom.png | side:r24_c53<br>top:r24_c57<br>bottom:r23_c56 | ⚠ 側面頂部有覆蓋層；頂/底面為依色彩最近鄰推測(距離 0/13)，請確認 |
| 206 | sift:void_obsidian | 虛空黑曜石 | The Sift 維度 | sift_void_obsidian.png | all:r22_c60 |  |
| 207 | sift:void_stone_01 | 虛黑岩 01 | The Sift 維度 | sift_void_stone_01.png | all:r22_c07 | 依色系自動命名，紋理需人工複核 |
| 208 | sift:void_stone_02 | 虛黑岩 02 | The Sift 維度 | sift_void_stone_02.png | all:r22_c08 | 依色系自動命名，紋理需人工複核 |
| 209 | sift:void_stone_03 | 虛黑岩 03 | The Sift 維度 | sift_void_stone_03.png | all:r22_c11 | 依色系自動命名，紋理需人工複核 |
| 210 | sift:void_stone_04 | 虛黑岩 04 | The Sift 維度 | sift_void_stone_04.png | all:r22_c13 | 依色系自動命名，紋理需人工複核 |
| 211 | sift:void_stone_05 | 虛黑岩 05 | The Sift 維度 | sift_void_stone_05.png | all:r22_c14 | 依色系自動命名，紋理需人工複核 |
| 212 | sift:void_stone_06 | 虛黑岩 06 | The Sift 維度 | sift_void_stone_06.png | all:r22_c17 | 依色系自動命名，紋理需人工複核 |
| 213 | sift:void_stone_07 | 虛黑岩 07 | The Sift 維度 | sift_void_stone_07.png | all:r22_c25 | 依色系自動命名，紋理需人工複核 |
| 214 | sift:void_stone_08 | 虛黑岩 08 | The Sift 維度 | sift_void_stone_08.png | all:r22_c31 | 依色系自動命名，紋理需人工複核 |
| 215 | sift:void_stone_09 | 虛黑岩 09 | The Sift 維度 | sift_void_stone_09.png | all:r22_c37 | 依色系自動命名，紋理需人工複核 |
| 216 | sift:void_stone_10 | 虛黑岩 10 | The Sift 維度 | sift_void_stone_10.png | all:r25_c03 | 依色系自動命名，紋理需人工複核 |
| 217 | sift:void_stone_11 | 虛黑岩 11 | The Sift 維度 | sift_void_stone_11.png | all:r25_c14 | 依色系自動命名，紋理需人工複核 |
| 218 | sift:void_stone_12 | 虛黑岩 12 | The Sift 維度 | sift_void_stone_12.png | all:r26_c62 | 依色系自動命名，紋理需人工複核 |
| 219 | sift:void_stone_13 | 虛黑岩 13 | The Sift 維度 | sift_void_stone_13.png | all:r27_c00 | 依色系自動命名，紋理需人工複核 |
| 220 | custom:amber_log | 琥珀原木 | 原版建築擴充 | custom_amber_log_side.png<br>custom_amber_log_top.png | side:r22_c58<br>top:r22_c59 | 木紋側面+年輪頂面，合併為單一原木 |
| 221 | custom:amber_sand | 琥珀沙 | 原版建築擴充 | custom_amber_sand.png | all:r23_c12 |  |
| 222 | custom:chiseled_stone_frame | 方框浮雕石 | 原版建築擴充 | custom_chiseled_stone_frame.png | all:r23_c06 |  |
| 223 | custom:cinnabar_planks | 朱砂木板 | 原版建築擴充 | custom_cinnabar_planks.png | all:r23_c04 | 木板，單一面 |
| 224 | custom:cobbled_dirt_01 | 碎石泥土 01 | 原版建築擴充 | custom_cobbled_dirt_01.png | all:r22_c61 | 依色系自動命名，紋理需人工複核 |
| 225 | custom:cobbled_dirt_02 | 碎石泥土 02 | 原版建築擴充 | custom_cobbled_dirt_02.png | all:r22_c62 | 依色系自動命名，紋理需人工複核 |
| 226 | custom:cobbled_dirt_03 | 碎石泥土 03 | 原版建築擴充 | custom_cobbled_dirt_03.png | all:r23_c00 | 依色系自動命名，紋理需人工複核 |
| 227 | custom:cobbled_dirt_04 | 碎石泥土 04 | 原版建築擴充 | custom_cobbled_dirt_04.png | all:r23_c24 | 依色系自動命名，紋理需人工複核 |
| 228 | custom:cobbled_dirt_05 | 碎石泥土 05 | 原版建築擴充 | custom_cobbled_dirt_05.png | all:r23_c25 | 依色系自動命名，紋理需人工複核 |
| 229 | custom:cobbled_dirt_06 | 碎石泥土 06 | 原版建築擴充 | custom_cobbled_dirt_06.png | all:r23_c26 | 依色系自動命名，紋理需人工複核 |
| 230 | custom:cobbled_dirt_07 | 碎石泥土 07 | 原版建築擴充 | custom_cobbled_dirt_07.png | all:r23_c27 | 依色系自動命名，紋理需人工複核 |
| 231 | custom:cobbled_dirt_08 | 碎石泥土 08 | 原版建築擴充 | custom_cobbled_dirt_08.png | all:r23_c29 | 依色系自動命名，紋理需人工複核 |
| 232 | custom:cobbled_dirt_09 | 碎石泥土 09 | 原版建築擴充 | custom_cobbled_dirt_09.png | all:r23_c30 | 依色系自動命名，紋理需人工複核 |
| 233 | custom:concentric_stone | 同心紋石 | 原版建築擴充 | custom_concentric_stone.png | all:r23_c16 |  |
| 234 | custom:dark_stone_01 | 深灰石 01 | 原版建築擴充 | custom_dark_stone_01.png | all:r23_c28 | 依色系自動命名，紋理需人工複核 |
| 235 | custom:dark_stone_02 | 深灰石 02 | 原版建築擴充 | custom_dark_stone_02.png | all:r27_c18 | 依色系自動命名，紋理需人工複核 |
| 236 | custom:dense_foliage_block | 濃密葉叢塊 | 原版建築擴充 | custom_dense_foliage_block.png | all:r22_c53 | 深綠純葉色，單一面 |
| 237 | custom:edged_stone_01 | 邊緣覆蓋石 01 | 原版建築擴充 | custom_edged_stone_01.png | all:r26_c55 | 依色系自動命名，紋理需人工複核 |
| 238 | custom:edged_stone_02 | 邊緣覆蓋石 02 | 原版建築擴充 | custom_edged_stone_02.png | all:r26_c56 | 依色系自動命名，紋理需人工複核 |
| 239 | custom:edged_stone_03 | 邊緣覆蓋石 03 | 原版建築擴充 | custom_edged_stone_03.png | all:r26_c57 | 依色系自動命名，紋理需人工複核 |
| 240 | custom:edged_stone_04 | 邊緣覆蓋石 04 | 原版建築擴充 | custom_edged_stone_04.png | all:r26_c58 | 依色系自動命名，紋理需人工複核 |
| 241 | custom:edged_stone_05 | 邊緣覆蓋石 05 | 原版建築擴充 | custom_edged_stone_05.png | all:r26_c59 | 依色系自動命名，紋理需人工複核 |
| 242 | custom:forest_floor_01 | 林地地表 01 | 原版建築擴充 | custom_forest_floor_01.png | all:r27_c23 | 依色系自動命名，紋理需人工複核 |
| 243 | custom:forest_floor_02 | 林地地表 02 | 原版建築擴充 | custom_forest_floor_02.png | all:r27_c24 | 依色系自動命名，紋理需人工複核 |
| 244 | custom:forest_floor_03 | 林地地表 03 | 原版建築擴充 | custom_forest_floor_03.png | all:r27_c25 | 依色系自動命名，紋理需人工複核 |
| 245 | custom:forest_floor_04 | 林地地表 04 | 原版建築擴充 | custom_forest_floor_04.png | all:r27_c26 | 依色系自動命名，紋理需人工複核 |
| 246 | custom:forest_floor_05 | 林地地表 05 | 原版建築擴充 | custom_forest_floor_05.png | all:r27_c27 | 依色系自動命名，紋理需人工複核 |
| 247 | custom:forest_floor_06 | 林地地表 06 | 原版建築擴充 | custom_forest_floor_06.png | all:r27_c28 | 依色系自動命名，紋理需人工複核 |
| 248 | custom:forest_floor_07 | 林地地表 07 | 原版建築擴充 | custom_forest_floor_07.png | all:r27_c29 | 依色系自動命名，紋理需人工複核 |
| 249 | custom:forest_floor_08 | 林地地表 08 | 原版建築擴充 | custom_forest_floor_08.png | all:r27_c30 | 依色系自動命名，紋理需人工複核 |
| 250 | custom:grassy_dirt_patch_a | 草斑泥土 A | 原版建築擴充 | custom_grassy_dirt_patch_a.png | all:r22_c55 | 泥土與草混合頂面變體 |
| 251 | custom:grassy_dirt_patch_b | 草斑泥土 B | 原版建築擴充 | custom_grassy_dirt_patch_b.png | all:r22_c56 |  |
| 252 | custom:grooved_stone_pillar | 凹槽石柱 | 原版建築擴充 | custom_grooved_stone_pillar_side.png<br>custom_grooved_stone_pillar_top.png | side:r23_c08<br>top:r23_c09 | 直條凹槽側面+同心方框頂面，合併為單一柱方塊 |
| 253 | custom:honey_planks | 蜂蜜木板 | 原版建築擴充 | custom_honey_planks.png | all:r23_c02 | 木板，單一面 |
| 254 | custom:meadow_grass_block | 草原草方塊 | 原版建築擴充 | custom_meadow_grass_block_top.png<br>custom_meadow_grass_block_side.png<br>custom_meadow_grass_block_bottom.png | top:r22_c52<br>side:r22_c50<br>bottom:r22_c49 | 底面採用相鄰的肥沃泥土貼圖(34)；若你另需獨立泥土方塊可複製 bottom |
| 255 | custom:meander_stone_bricks | 回紋石磚 | 原版建築擴充 | custom_meander_stone_bricks.png | all:r23_c07 |  |
| 256 | custom:mossy_stone_01 | 苔蘚石 01 | 原版建築擴充 | custom_mossy_stone_01.png | all:r22_c47 | 依色系自動命名，紋理需人工複核 |
| 257 | custom:mossy_stone_02 | 苔蘚石 02 | 原版建築擴充 | custom_mossy_stone_02.png | all:r22_c48 | 依色系自動命名，紋理需人工複核 |
| 258 | custom:mossy_stone_03 | 苔蘚石 03 | 原版建築擴充 | custom_mossy_stone_03.png | all:r23_c17 | 依色系自動命名，紋理需人工複核 |
| 259 | custom:mossy_stone_04 | 苔蘚石 04 | 原版建築擴充 | custom_mossy_stone_04.png | all:r23_c21 | 依色系自動命名，紋理需人工複核 |
| 260 | custom:mossy_stone_05 | 苔蘚石 05 | 原版建築擴充 | custom_mossy_stone_05.png | all:r23_c22 | 依色系自動命名，紋理需人工複核 |
| 261 | custom:olive_earth_01 | 橄欖土 01 | 原版建築擴充 | custom_olive_earth_01.png | all:r27_c07 | 依色系自動命名，紋理需人工複核 |
| 262 | custom:olive_earth_02 | 橄欖土 02 | 原版建築擴充 | custom_olive_earth_02.png | all:r27_c08 | 依色系自動命名，紋理需人工複核 |
| 263 | custom:pale_sand | 淺沙 | 原版建築擴充 | custom_pale_sand.png | all:r23_c13 |  |
| 264 | custom:pale_streak_log_a | 淺紋原木 A | 原版建築擴充 | custom_pale_streak_log_a_side.png | side:r27_c12 | ⚠ 找不到對應頂面，暫以側面代替 |
| 265 | custom:pale_streak_log_b | 淺紋原木 B | 原版建築擴充 | custom_pale_streak_log_b_side.png | side:r27_c16 | ⚠ 找不到對應頂面，暫以側面代替 |
| 266 | custom:rich_dirt_01 | 肥沃泥土 01 | 原版建築擴充 | custom_rich_dirt_01.png | all:r27_c01 | 依色系自動命名，紋理需人工複核 |
| 267 | custom:rich_dirt_02 | 肥沃泥土 02 | 原版建築擴充 | custom_rich_dirt_02.png | all:r27_c02 | 依色系自動命名，紋理需人工複核 |
| 268 | custom:rich_dirt_03 | 肥沃泥土 03 | 原版建築擴充 | custom_rich_dirt_03.png | all:r27_c03 | 依色系自動命名，紋理需人工複核 |
| 269 | custom:ridge_stone_01 | 脊紋石 01 | 原版建築擴充 | custom_ridge_stone_01.png | all:r25_c46 | 三角陰影斜面紋，可能是屋脊/斜面用途 |
| 270 | custom:ridge_stone_02 | 脊紋石 02 | 原版建築擴充 | custom_ridge_stone_02.png | all:r25_c47 | 三角陰影斜面紋，可能是屋脊/斜面用途 |
| 271 | custom:ridge_stone_03 | 脊紋石 03 | 原版建築擴充 | custom_ridge_stone_03.png | all:r25_c50 | 三角陰影斜面紋，可能是屋脊/斜面用途 |
| 272 | custom:ridge_stone_04 | 脊紋石 04 | 原版建築擴充 | custom_ridge_stone_04.png | all:r25_c51 | 三角陰影斜面紋，可能是屋脊/斜面用途 |
| 273 | custom:rosewood_planks | 玫瑰木板 | 原版建築擴充 | custom_rosewood_planks.png | all:r23_c01 | 木板，單一面 |
| 274 | custom:russet_log | 赤褐原木 | 原版建築擴充 | custom_russet_log_side.png<br>custom_russet_log_top.png | side:r27_c11<br>top:r26_c54 | ⚠ 頂面為依色系推測(借用254)，請確認 |
| 275 | custom:sandy_stone_01 | 砂質石 01 | 原版建築擴充 | custom_sandy_stone_01.png | all:r26_c14 | 依色系自動命名，紋理需人工複核 |
| 276 | custom:sandy_stone_02 | 砂質石 02 | 原版建築擴充 | custom_sandy_stone_02.png | all:r26_c33 | 依色系自動命名，紋理需人工複核 |
| 277 | custom:sandy_stone_03 | 砂質石 03 | 原版建築擴充 | custom_sandy_stone_03.png | all:r26_c34 | 依色系自動命名，紋理需人工複核 |
| 278 | custom:sandy_stone_04 | 砂質石 04 | 原版建築擴充 | custom_sandy_stone_04.png | all:r26_c35 | 依色系自動命名，紋理需人工複核 |
| 279 | custom:sandy_stone_05 | 砂質石 05 | 原版建築擴充 | custom_sandy_stone_05.png | all:r26_c36 | 依色系自動命名，紋理需人工複核 |
| 280 | custom:smooth_stone_01 | 平滑石 01 | 原版建築擴充 | custom_smooth_stone_01.png | all:r22_c33 | 依色系自動命名，紋理需人工複核 |
| 281 | custom:smooth_stone_02 | 平滑石 02 | 原版建築擴充 | custom_smooth_stone_02.png | all:r22_c45 | 依色系自動命名，紋理需人工複核 |
| 282 | custom:smooth_stone_03 | 平滑石 03 | 原版建築擴充 | custom_smooth_stone_03.png | all:r22_c46 | 依色系自動命名，紋理需人工複核 |
| 283 | custom:smooth_stone_04 | 平滑石 04 | 原版建築擴充 | custom_smooth_stone_04.png | all:r22_c54 | 依色系自動命名，紋理需人工複核 |
| 284 | custom:smooth_stone_05 | 平滑石 05 | 原版建築擴充 | custom_smooth_stone_05.png | all:r23_c14 | 依色系自動命名，紋理需人工複核 |
| 285 | custom:smooth_stone_06 | 平滑石 06 | 原版建築擴充 | custom_smooth_stone_06.png | all:r26_c10 | 依色系自動命名，紋理需人工複核 |
| 286 | custom:smooth_stone_07 | 平滑石 07 | 原版建築擴充 | custom_smooth_stone_07.png | all:r26_c11 | 依色系自動命名，紋理需人工複核 |
| 287 | custom:stone_bricks_01 | 石磚 01 | 原版建築擴充 | custom_stone_bricks_01.png | all:r22_c18 | 依色系自動命名，紋理需人工複核 |
| 288 | custom:stone_bricks_02 | 石磚 02 | 原版建築擴充 | custom_stone_bricks_02.png | all:r22_c42 | 依色系自動命名，紋理需人工複核 |
| 289 | custom:stone_bricks_03 | 石磚 03 | 原版建築擴充 | custom_stone_bricks_03.png | all:r23_c05 | 依色系自動命名，紋理需人工複核 |
| 290 | custom:stone_bricks_04 | 石磚 04 | 原版建築擴充 | custom_stone_bricks_04.png | all:r23_c15 | 依色系自動命名，紋理需人工複核 |
| 291 | custom:stone_bricks_05 | 石磚 05 | 原版建築擴充 | custom_stone_bricks_05.png | all:r23_c20 | 依色系自動命名，紋理需人工複核 |
| 292 | custom:stone_bricks_06 | 石磚 06 | 原版建築擴充 | custom_stone_bricks_06.png | all:r23_c23 | 依色系自動命名，紋理需人工複核 |
| 293 | custom:stone_variant_01 | 灰石變體 01 | 原版建築擴充 | custom_stone_variant_01.png | all:r27_c17 | 依色系自動命名，紋理需人工複核 |
| 294 | custom:umber_log | 赭褐原木 | 原版建築擴充 | custom_umber_log_side.png<br>custom_umber_log_top.png | side:r26_c53<br>top:r26_c54 | 深色樹皮+金色年輪，合併為單一原木 |
| 295 | custom:walnut_planks | 胡桃木板 | 原版建築擴充 | custom_walnut_planks.png | all:r23_c03 | 木板，單一面 |
